// NayPict Progressive Web App (PWA) Service Worker with intelligent offline caching.

const CACHE_NAME = 'naypict-static-v1';
const MEDIA_CACHE_NAME = 'naypict-media-v1';

const PRECACHE_ASSETS = [
  '/',
  '/photos',
  '/naypict-icon.svg',
  '/favicon.ico',
  '/manifest.webmanifest',
];

// Install Event: Pre-cache critical application shell assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_ASSETS).catch((err) => {
        console.warn('[PWA-SW] Pre-caching warning:', err);
      });
    })
  );
  self.skipWaiting();
});

const MAX_MEDIA_CACHE_ITEMS = 150;

/**
 * Prune media cache to a maximum number of items using FIFO/LRU eviction.
 * Prevents mobile device storage from being exhausted over time.
 */
async function trimMediaCache(cacheName, maxItems) {
  try {
    const cache = await caches.open(cacheName);
    const keys = await cache.keys();
    if (keys.length > maxItems) {
      const toDelete = keys.slice(0, keys.length - maxItems);
      await Promise.all(toDelete.map((key) => cache.delete(key)));
    }
  } catch (err) {
    // Ignore cache trimming errors in background
  }
}

// Activate Event: Clean up outdated caches and enforce media storage limit
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(async (keys) => {
      await Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME && key !== MEDIA_CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
      await trimMediaCache(MEDIA_CACHE_NAME, MAX_MEDIA_CACHE_ITEMS);
    })
  );
  self.clients.claim();
});

// Fetch Event: Cache-First for media, Stale-While-Revalidate for static assets, Network-First for HTML
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Only handle GET requests with http/https protocols
  if (request.method !== 'GET' || !url.protocol.startsWith('http')) {
    return;
  }

  // Never cache API calls, SSE streaming, or non-same-origin API endpoints
  if (url.pathname.startsWith('/api') || url.pathname.includes('/sse')) {
    return;
  }

  // 1. Photo Media & Derivative Images: Stale-While-Revalidate with bounded media cache (max 150 items)
  // Strictly respects Cache-Control: never persists private or no-store media (SEC-PHASE3-01)
  if (url.pathname.startsWith('/media/') || request.destination === 'image') {
    const isCacheableMedia = (res) => {
      if (!res || res.status !== 200) return false;
      const cc = (res.headers.get('cache-control') || '').toLowerCase();
      return !cc.includes('private') && !cc.includes('no-store');
    };

    event.respondWith(
      caches.open(MEDIA_CACHE_NAME).then(async (cache) => {
        const cachedResponse = await cache.match(request);
        if (cachedResponse) {
          // Fetch fresh version in background if online
          fetch(request)
            .then((networkResponse) => {
              if (isCacheableMedia(networkResponse)) {
                const responseToCache = networkResponse.clone();
                cache.put(request, responseToCache).then(() => {
                  trimMediaCache(MEDIA_CACHE_NAME, MAX_MEDIA_CACHE_ITEMS);
                });
              } else if (networkResponse && networkResponse.status === 200) {
                // If the updated response is private/no-store, evict stale entry from cache
                cache.delete(request);
              }
            })
            .catch(() => {});
          return cachedResponse;
        }

        // Otherwise fetch from network and cache if public
        return fetch(request)
          .then((networkResponse) => {
            if (isCacheableMedia(networkResponse)) {
              const responseToCache = networkResponse.clone();
              cache.put(request, responseToCache).then(() => {
                trimMediaCache(MEDIA_CACHE_NAME, MAX_MEDIA_CACHE_ITEMS);
              });
            }
            return networkResponse;
          })
          .catch(() => {
            return cachedResponse || new Response('Image unavailable offline', { status: 503 });
          });
      })
    );
    return;
  }

  // 2. Navigation / Page Requests: Network-First with offline fallback
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request).catch(async () => {
        const cache = await caches.open(CACHE_NAME);
        const cachedPage = await cache.match(request);
        return cachedPage || (await cache.match('/photos')) || (await cache.match('/'));
      })
    );
    return;
  }

  // 3. Static Assets (CSS, JS, Fonts): Stale-While-Revalidate
  event.respondWith(
    caches.match(request).then((cachedResponse) => {
      const fetchPromise = fetch(request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(request, responseToCache);
            });
          }
          return networkResponse;
        })
        .catch(() => cachedResponse);

      return cachedResponse || fetchPromise;
    })
  );
});
